

let MenuData = {

    "menu" : {
        "slice of pizza": "2.00",
        "toppings": {
            "pepperoni": ".25",
            "meatballs": ".35",
            "mushrooms": ".40",
            "olives": ".20"
        },
        "sides": {
            "potato salad": "1.25",
            "hummus": "2.50",
            "caesar salad": "3.50",
            "garden salad": "2.25"
        },
        "drinks": {
            "soda": {
                "small": "1.95",
                "medium": "2.20",
                "large": "2.50"
            },
            "juice": "2.00",
            "water": "1.25"
        }
    }


};


//fetch the JSON data from locally(which is already saved in our folder or file)

fetch("./menu.json")
.then(response => {
   return response.json();
})
.then(data => console.log(data));




//Print the JSON data using pure JavaScript

function menuList() {  
    let cont = document.querySelector('.container');
    const ul = document.createElement('ul');
    ul.setAttribute('id', 'menu-list');

    for(var i in MenuData['menu']){
    if (typeof(MenuData)['menu'][i] == "object") {
        const li = document.createElement('li');
        li.innerHTML = i;
        ul.appendChild(li);

        const childul = document.createElement('ul');
        for(var j in MenuData['menu'][i]){
            if(typeof MenuData['menu'][i][j]=="object"){
                const li = document.createElement('li');
                li.innerHTML = j;
                childul.appendChild(li);

                const grandchild = document.createElement('ul');
                for(var k in MenuData['menu'][i][j]){
                    const li = document.createElement('li');
                    li.innerHTML=k;
                    grandchild.appendChild(li);
                }
                li.appendChild(grandchild);
            }
            else{
                const li = document.createElement('li');
                li.innerHTML = j;
                childul.appendChild(li);
            }
        }
        li.appendChild(childul);
    }
    else{
        const li = document.createElement('li');
        li.innerHTML = i;
        ul.appendChild(li);
    }
    }
cont.appendChild(ul);
    }

    menuList();


        
//show the order 

const btn = document.querySelector('#order');
const cont = document.querySelector('#orderlist');
const ul = document.createElement('ul');



btn.addEventListener('click', () => {
   
    cont.textContent="";
    // let orderList = [];
    // cont.innerHTML=" ";
    const  orderList = JSON.parse(localStorage.getItem('order'));
    //  localStorage.setItem('dataKey', JSON.parse(order ));
    // var val = localStorage.getItem('dataKey');
    if(orderList == null){
        alert('Select at least one food item..!');
    }
        else{
            ul.classList.add("my-order");
            orderList.map((order) => {
                const li = document.createElement('li');
                li.innerHTML = order;
                // if(btn.order){
                //     btn.removeEventListener;
                // }

                ul.appendChild(li);
            })
            cont.appendChild(ul);

            // cont.replaceChild(ul, orderList[0]);
        }
        
})
    


// //save order

// var orders = [];
// document.addEventListener('click', function (event) {
// document.querySelector('#order').innerHTML=orders;

// function myFunction() {
//     orders.push('Disha');
//     document.querySelector('#order').innerHTML=orders;
// }
// });




var orders = [];
// let len;
// var chileNodes=[0];
// localStorage.setItem('menuList', JSON.stringify(event));
document.addEventListener('click', function (event) {
    if (event.target == btn) {
        return;
        
    }else{;
        
        // function fillArray(value, len) {
            // var arr = [];
            // for (var i = 0; i < len; i++) {
           
        orders.push(event.target.innerHTML);
            
        localStorage.setItem('order',JSON.stringify(orders));
        console.log(event.target);
            return orders;
    }
// }
});



// function fillArray(value, len) {
//     var arr = [];
//     for (var i = 0; i < len; i++) {
//       arr.push(value);
//     }
//     return arr;
//   }





